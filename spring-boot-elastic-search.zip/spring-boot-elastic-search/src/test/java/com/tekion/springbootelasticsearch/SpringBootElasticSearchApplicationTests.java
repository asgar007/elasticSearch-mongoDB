package com.tekion.springbootelasticsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootElasticSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
