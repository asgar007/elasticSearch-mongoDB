package com.tekion.springbootelasticsearch;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SprintElasticControllerTest {
}
