package com.tekion.springbootelasticsearch;

import com.tekion.springbootelasticsearch.mongo.repository.SprintMongoRepository;
import com.tekion.springbootelasticsearch.mongo.service.SprintMongoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
@SpringBootTest
public class SprintServiceTest {
    @Autowired
    private SprintMongoService sprintMongoService;

    @MockBean
    private SprintMongoRepository sprintMongoRepository;
    @Test
    public void getAllSprint(){

    }
}
