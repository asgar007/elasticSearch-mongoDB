package com.tekion.springbootelasticsearch.mongo.service;

import com.tekion.springbootelasticsearch.dto.TaskDTO;

import java.util.List;

public interface TaskService {
    TaskDTO createTask(TaskDTO taskDTO);
    List<TaskDTO> getAlltasks();

    //String updateTaskStatus(String taskId);
//    Task updateTaskStatus(String taskId, TaskStatus newStatus);
//    List<Task> getDelayedTask();
//    List<Task> getTasksByStatus(TaskStatus status);
//    Optional<Task> getTasksAssignedToUser(String userId);
}
