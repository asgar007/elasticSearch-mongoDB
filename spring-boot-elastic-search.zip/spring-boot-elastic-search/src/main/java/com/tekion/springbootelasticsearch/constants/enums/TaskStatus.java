package com.tekion.springbootelasticsearch.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum TaskStatus {
    TO_DO,
    DEV_IN_PROGRESS,
    DONE;
}
