package com.tekion.springbootelasticsearch.mongo.entity;

import com.tekion.springbootelasticsearch.audit.Auditable;
import com.tekion.springbootelasticsearch.constants.enums.TaskStatus;
import com.tekion.springbootelasticsearch.constants.enums.TaskType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@EqualsAndHashCode(callSuper = true)
@Document(collection = "tasks")
public class Task extends Auditable<String> {
    @Id
    private String taskId;
    private String taskName;
    private String sprintId;
    private TaskType type;
    private TaskStatus status;
    private String assignee;
    private String reporter;
}
