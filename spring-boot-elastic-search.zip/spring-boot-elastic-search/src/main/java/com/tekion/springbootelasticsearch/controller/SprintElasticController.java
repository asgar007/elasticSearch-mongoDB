package com.tekion.springbootelasticsearch.controller;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.response.SuccessResponse;
import com.tekion.springbootelasticsearch.service.SprintService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/elastic")
@RequiredArgsConstructor
public class SprintElasticController {

    private final SprintService sprintService;

    @PostMapping
    public ResponseEntity<SuccessResponse> createSprint(@RequestBody SprintDTO sprintDTO){
        return  ResponseEntity.ok()
                .body(SuccessResponse.builder().data(sprintService.createSprint(sprintDTO)).build());
    }
    @GetMapping("sprints")
    public ResponseEntity<SuccessResponse> getAllSprints() {
        return ResponseEntity.ok().body(SuccessResponse.builder().data(sprintService.getAllSprints()).build());
    }

    @GetMapping("sprint/{sprintId}")
    public ResponseEntity<SuccessResponse> getSprintBySprintId(@PathVariable String sprintId){
        return ResponseEntity.ok().body(SuccessResponse.builder().data(sprintService.getSprintBySprintId(sprintId)).build());
    }

}
