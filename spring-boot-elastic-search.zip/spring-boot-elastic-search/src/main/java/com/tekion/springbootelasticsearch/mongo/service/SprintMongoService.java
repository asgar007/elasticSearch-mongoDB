package com.tekion.springbootelasticsearch.mongo.service;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.dto.TaskDTO;

import java.util.List;
import java.util.Optional;

public interface SprintMongoService {

    SprintDTO createSprint(SprintDTO sprintDTO);

     List<SprintDTO> getAllSprints();
     List<TaskDTO> getAllTasksInSprint(String sprintId);

    Optional<SprintDTO> getSprintBySprintId(String sprintId);
}
