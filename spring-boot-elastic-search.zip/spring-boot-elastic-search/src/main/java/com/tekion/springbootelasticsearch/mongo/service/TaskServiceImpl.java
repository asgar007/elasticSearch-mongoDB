package com.tekion.springbootelasticsearch.mongo.service;

import com.tekion.springbootelasticsearch.dto.TaskDTO;
import com.tekion.springbootelasticsearch.mongo.entity.Task;
import com.tekion.springbootelasticsearch.mongo.repository.TaskMongoRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

    private final TaskMongoRepository taskMongoRepository;
    private final ModelMapper modelMapper;

    @Override
    public TaskDTO createTask(TaskDTO taskDTO) {
        Task task = modelMapper.map(taskDTO, Task.class);
        Task createdTask = taskMongoRepository.save(task);
        return modelMapper.map(createdTask, TaskDTO.class);
    }

    @Override
    public List<TaskDTO> getAlltasks() {
        return taskMongoRepository.findAll().stream().map(
                task -> modelMapper.map(task, TaskDTO.class)
        ).collect(Collectors.toList());
    }


}
