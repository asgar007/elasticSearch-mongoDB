package com.tekion.springbootelasticsearch.controller;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.mongo.entity.Sprint;
import com.tekion.springbootelasticsearch.mongo.repository.SprintMongoRepository;
import com.tekion.springbootelasticsearch.mongo.service.SprintMongoService;
import com.tekion.springbootelasticsearch.repository.SprintElasticRepository;
import com.tekion.springbootelasticsearch.response.SuccessResponse;
import com.tekion.springbootelasticsearch.service.SprintService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class MongoElasticController {
    private final SprintMongoService sprintMongoService;
    private final SprintService sprintService;
    private final ModelMapper modelMapper;
    @PostMapping
    public ResponseEntity<SuccessResponse> createSprint(@RequestBody SprintDTO sprintDTO){
        /*Save in Mongodb first then on Elastic search*/
        return ResponseEntity.ok()
                .body(SuccessResponse.builder().error(false).statusCode(HttpStatus.CREATED.toString())
                        .data(sprintService.createSprint(sprintMongoService.createSprint(sprintDTO))).build());
    }
}
