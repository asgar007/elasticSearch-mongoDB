package com.tekion.springbootelasticsearch.mongo.entity;

import com.tekion.springbootelasticsearch.audit.Auditable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


import java.util.ArrayList;
import java.util.List;
@Data
@EqualsAndHashCode(callSuper = true)
@Document(collection = "sprints")
public class Sprint extends Auditable<String> {
    @Id
    private String sprintId;
    private String sprintName;
}
