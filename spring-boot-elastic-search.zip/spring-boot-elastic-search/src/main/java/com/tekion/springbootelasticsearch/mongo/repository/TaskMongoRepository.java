package com.tekion.springbootelasticsearch.mongo.repository;

import com.tekion.springbootelasticsearch.mongo.entity.Task;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface TaskMongoRepository extends MongoRepository<Task, String> {
    List<Task> findAllBySprintId(String sprintId);
}
