package com.tekion.springbootelasticsearch.dto;

import com.tekion.springbootelasticsearch.constants.enums.TaskStatus;
import com.tekion.springbootelasticsearch.constants.enums.TaskType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskDTO {
    private String taskId;
    private String taskName;
    private TaskType type;
    private TaskStatus status;
    private String sprintId;
    private String assignee;
    private String reporter;
    protected String createdBy;
    protected Date createdDate;
    protected String lastModifiedBy;
    protected Date lastModifiedDate;
}
