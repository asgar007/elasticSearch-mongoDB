package com.tekion.springbootelasticsearch.mongo.repository;

import com.tekion.springbootelasticsearch.mongo.entity.Sprint;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SprintMongoRepository extends MongoRepository<Sprint, String> {
}
