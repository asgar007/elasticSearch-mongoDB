package com.tekion.springbootelasticsearch.constants.enums;

public enum TaskType {
    STORY,
    FEATURE,
    BUG
}
