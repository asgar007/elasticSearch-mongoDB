package com.tekion.springbootelasticsearch.mongo.service;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.dto.TaskDTO;
import com.tekion.springbootelasticsearch.mongo.entity.Sprint;
import com.tekion.springbootelasticsearch.mongo.entity.Task;
import com.tekion.springbootelasticsearch.mongo.repository.SprintMongoRepository;
import com.tekion.springbootelasticsearch.mongo.repository.TaskMongoRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SprintMongoServiceImpl implements SprintMongoService{

    private final ModelMapper modelMapper;
    private final SprintMongoRepository sprintMongoRepository;
    private final TaskMongoRepository taskMongoRepository;
    @Override
    public SprintDTO createSprint(SprintDTO sprintDTO) {
        /*Convert DTO to Entity and then To DTO*/
//        if(1==1)throw new IllegalStateException("jgchghccgchgc");
        Sprint sprint = modelMapper.map(sprintDTO, Sprint.class);
        Sprint createdSprint = sprintMongoRepository.save(sprint);
        return modelMapper.map(createdSprint, SprintDTO.class);
    }
    @Override
    public List<SprintDTO> getAllSprints() {
        /*Converting sprints to sprintDTOs*/
        return sprintMongoRepository.findAll().stream().map(
                sprint->modelMapper.map(sprint, SprintDTO.class)
        ).collect(Collectors.toList());
    }

    @Override
    public List<TaskDTO> getAllTasksInSprint(String sprintId) {
       return taskMongoRepository.findAllBySprintId(sprintId).stream().map(
                task->modelMapper.map(task, TaskDTO.class)
        ).collect(Collectors.toList());
    }


    @Override
    public Optional<SprintDTO> getSprintBySprintId(String sprintId) {
        return sprintMongoRepository.findById(sprintId).map(sprint->modelMapper.map(sprint,SprintDTO.class));
    }

    private Optional<TaskDTO> getTaskByTaskId(String taskId){
        return taskMongoRepository.findById(taskId).map(task -> modelMapper.map(task, TaskDTO.class));
    }
}
