package com.tekion.springbootelasticsearch.repository;

import com.tekion.springbootelasticsearch.entity.Sprint;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface SprintElasticRepository extends ElasticsearchRepository<Sprint, String> {
}
