package com.tekion.springbootelasticsearch.service;

import com.tekion.springbootelasticsearch.dto.TaskDTO;
import com.tekion.springbootelasticsearch.entity.Task;
import com.tekion.springbootelasticsearch.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
public class TaskElasticServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final ModelMapper modelMapper;

    @Override
    public TaskDTO createTask(TaskDTO taskDTO) {
        Task task = modelMapper.map(taskDTO, Task.class);
        Task createdTask = taskRepository.save(task);
        return modelMapper.map(createdTask, TaskDTO.class);
    }

    @Override
    public List<TaskDTO> getAlltasks() {
        List<TaskDTO> taskDTOS = new ArrayList<>();
        taskRepository.findAll().forEach(task -> {
            TaskDTO taskdto = modelMapper.map(task, TaskDTO.class);
            taskDTOS.add(taskdto);
        });
        return taskDTOS;
    }

}
