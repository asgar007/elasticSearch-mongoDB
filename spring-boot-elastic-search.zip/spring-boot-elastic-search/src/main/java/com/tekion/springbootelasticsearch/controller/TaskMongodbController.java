package com.tekion.springbootelasticsearch.controller;

import com.tekion.springbootelasticsearch.dto.TaskDTO;
import com.tekion.springbootelasticsearch.mongo.service.TaskService;
import com.tekion.springbootelasticsearch.response.SuccessResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/task/mongo")
@RequiredArgsConstructor
public class TaskMongodbController {

    private final TaskService taskService;

    @PostMapping
    public ResponseEntity<SuccessResponse> createTask(@RequestBody TaskDTO taskDTO){
        return ResponseEntity.ok()
                .body(SuccessResponse.builder().error(false).message("Task Created").data(taskService.createTask(taskDTO)).build());
    }
    @GetMapping("tasks")
    public ResponseEntity<SuccessResponse> getAllTasks(){
        return ResponseEntity.ok()
                .body(SuccessResponse.builder().error(false).message("List of Tasks").data(taskService.getAlltasks()).build());
    }

//    @PutMapping("task/{taskId}")
//    public ResponseEntity<SuccessResponse> updateTaskStatus(@PathVariable String taskId){
//        return ResponseEntity.ok()
//                .body(SuccessResponse.builder().error(false).statusCode(HttpStatus.OK.toString())
//                        .data(taskService.updateTaskStatus(taskId)).build());
//    }
}
