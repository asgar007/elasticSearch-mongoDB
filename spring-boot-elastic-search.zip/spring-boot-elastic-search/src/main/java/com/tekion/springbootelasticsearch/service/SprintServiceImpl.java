package com.tekion.springbootelasticsearch.service;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.entity.Sprint;
import com.tekion.springbootelasticsearch.repository.SprintElasticRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor
public class SprintServiceImpl implements SprintService{

    private final SprintElasticRepository sprintElasticRepository;
    private final ModelMapper modelMapper;
//    private final ElasticsearchOperations elasticsearchOperations;
    @Override
    public SprintDTO createSprint(SprintDTO sprintDTO) {
        Sprint sprint = modelMapper.map(sprintDTO, Sprint.class);
        return modelMapper.map(sprintElasticRepository.save(sprint), SprintDTO.class);
    }

    @Override
    public List<SprintDTO> getAllSprints() {
        List<SprintDTO> sprintDTOList = new ArrayList<>();
        sprintElasticRepository.findAll().forEach(
            sprint ->  {
                SprintDTO sprintDTO = modelMapper.map(sprint, SprintDTO.class);
                sprintDTOList.add(sprintDTO);
            }
        );
        return sprintDTOList;
    }
    @Override
    public Optional<SprintDTO> getSprintBySprintId(String sprintId) {
        return sprintElasticRepository.findById(sprintId)
                .map(sprint -> modelMapper.map(sprint, SprintDTO.class));
    }
}
