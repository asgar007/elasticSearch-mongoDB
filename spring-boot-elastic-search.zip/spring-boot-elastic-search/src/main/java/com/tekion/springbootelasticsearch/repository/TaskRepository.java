package com.tekion.springbootelasticsearch.repository;

import com.tekion.springbootelasticsearch.entity.Task;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;


import java.util.List;

public interface TaskRepository extends ElasticsearchRepository<Task, String> {
    List<Task> findAllBySprintId(String sprintId);
}
