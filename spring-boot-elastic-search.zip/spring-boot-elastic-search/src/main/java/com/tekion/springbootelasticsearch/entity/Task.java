package com.tekion.springbootelasticsearch.entity;

import com.tekion.springbootelasticsearch.constants.enums.TaskStatus;
import com.tekion.springbootelasticsearch.constants.enums.TaskType;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Data
@Document(indexName = "tasks")
public class Task {
    @Id
    private String taskId;
    private String taskName;
    private String sprintId;
    private TaskType type;
    private TaskStatus status;
    private String assignee;
    private String reporter;
}
