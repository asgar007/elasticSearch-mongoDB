package com.tekion.springbootelasticsearch.constants;

public class KafkaConstants {
    public static final String TOPIC_NAME = "tekion-topic";
    public static final String INDEX_NAME = "sprint_index";
    public static final String GROUP_ID = "group_id";
}
