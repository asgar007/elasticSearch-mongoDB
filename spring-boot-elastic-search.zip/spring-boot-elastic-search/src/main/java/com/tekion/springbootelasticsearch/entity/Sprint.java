package com.tekion.springbootelasticsearch.entity;

import com.tekion.springbootelasticsearch.audit.Auditable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
@Data
@EqualsAndHashCode(callSuper = true)
@Document(indexName = "sprints")
public class Sprint extends Auditable<String> {
    @Id
    private String sprintId;
    private String sprintName;
}
