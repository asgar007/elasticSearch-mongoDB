package com.tekion.springbootelasticsearch.controller;

import com.tekion.springbootelasticsearch.dto.SprintDTO;
import com.tekion.springbootelasticsearch.mongo.service.SprintMongoService;
import com.tekion.springbootelasticsearch.response.SuccessResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/sprint/mongo")
@RequiredArgsConstructor
public class SprintMongodbController {

    private final SprintMongoService sprintMongoService;

    @PostMapping
    public ResponseEntity<SuccessResponse> createSprint(@RequestBody SprintDTO sprintDTO){
        return  ResponseEntity.ok()
                .body(SuccessResponse.builder().error(false).statusCode(HttpStatus.CREATED.toString())
                        .message("sprint created keep coding hard!!")
                        .data(sprintMongoService.createSprint(sprintDTO)).build());
    }
    @GetMapping("sprints")
    public ResponseEntity<SuccessResponse> getAllSprints() {
        return ResponseEntity.ok().body(SuccessResponse.builder().data(sprintMongoService.getAllSprints()).build());
    }

    @GetMapping("sprint/{sprintId}")
    public ResponseEntity<SuccessResponse> getSprintBySprintId(@PathVariable String sprintId){
        return ResponseEntity.ok().body(SuccessResponse.builder().data(sprintMongoService.getSprintBySprintId(sprintId)).build());
    }
    @GetMapping("tasks/{sprintId}")
    public ResponseEntity<SuccessResponse> getAllTasksInSprint(@PathVariable String sprintId){
        return ResponseEntity.ok()
                .body(SuccessResponse.builder().error(false).statusCode(HttpStatus.OK.toString())
                        .message(String.format("list of tasks of sprintId: %s",sprintId))
                        .data(sprintMongoService.getAllTasksInSprint(sprintId)).build());
    }
}
