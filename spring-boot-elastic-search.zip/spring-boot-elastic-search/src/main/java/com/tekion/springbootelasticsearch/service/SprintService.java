package com.tekion.springbootelasticsearch.service;

import com.tekion.springbootelasticsearch.dto.SprintDTO;

import java.util.List;
import java.util.Optional;

public interface SprintService {
    SprintDTO createSprint(SprintDTO sprintDTO);
    List<SprintDTO> getAllSprints();

    Optional<SprintDTO> getSprintBySprintId(String sprintId);
}
